#!/usr/bin/env python

from brain_games.game_starter import play_game


def main():
    play_game()


if __name__ == '__main__':
    main()
