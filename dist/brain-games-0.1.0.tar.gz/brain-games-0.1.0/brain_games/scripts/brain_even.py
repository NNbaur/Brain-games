from brain_games.game_starter import welcome_user, start_game


def main():
    start_game('brain_even.initial_game_data()', welcome_user())


if __name__ == '__main__':
    main()
